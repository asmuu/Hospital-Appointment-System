package com.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.model.Patient;

public interface Patientrepo extends JpaRepository<Patient, Integer>
{
	Patient findByEmail(String email);
}
