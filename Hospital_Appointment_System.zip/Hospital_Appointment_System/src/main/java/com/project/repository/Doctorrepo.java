package com.project.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.project.model.Doctor;
import com.project.model.Patient;
public interface Doctorrepo extends JpaRepository<Doctor, Integer>
{
	Doctor findById(int id);
	List<Doctor> findByName(String name);
}
