package com.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.model.Appoinment;


public interface Appoinmentrepo extends JpaRepository<Appoinment, Integer>
{
	List<Appoinment> findByName(String name);
}
