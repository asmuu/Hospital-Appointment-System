package com.project.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Appoinment 
{
	@Id
	private int id;
	private String name;
	private String Mobile;
	private String Address;
	private String date;
	private String time;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return Mobile;
	}
	public void setMobile(String mobile) {
		Mobile = mobile;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public Appoinment(int id, String name, String mobile, String address, String date, String time) {
		super();
		this.id = id;
		this.name = name;
		Mobile = mobile;
		Address = address;
		this.date = date;
		this.time = time;
	}
	public Appoinment() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Appoinment [id=" + id + ", name=" + name + ", Mobile=" + Mobile + ", Address=" + Address + ", date="
				+ date + ", time=" + time + "]";
	}
	
	
}
