package com.project.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Doctor 
{
	@Id
	private int id;
	private String name;
	private String degree;
	private String Specialist;
	private String mobile;
	private String entry_time;
	private String exit_time;
	private String password;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public String getSpecialist() {
		return Specialist;
	}
	public void setSpecialist(String specialist) {
		Specialist = specialist;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEntry_time() {
		return entry_time;
	}
	public void setEntry_time(String entry_time) {
		this.entry_time = entry_time;
	}
	public String getExit_time() {
		return exit_time;
	}
	public void setExit_time(String exit_time) {
		this.exit_time = exit_time;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Doctor(int id, String name, String degree, String specialist, String mobile, String entry_time,
			String exit_time, String password) {
		super();
		this.id = id;
		this.name = name;
		this.degree = degree;
		Specialist = specialist;
		this.mobile = mobile;
		this.entry_time = entry_time;
		this.exit_time = exit_time;
		this.password = password;
	}
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Doctor [id=" + id + ", name=" + name + ", degree=" + degree + ", Specialist=" + Specialist + ", mobile="
				+ mobile + ", entry_time=" + entry_time + ", exit_time=" + exit_time + ", password=" + password + "]";
	}
	
	
	
}
