package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.model.Appoinment;
import com.project.model.Contact;
import com.project.model.Patient;
import com.project.repository.Appoinmentrepo;
import com.project.repository.Contactrepo;
import com.project.repository.Patientrepo;


@Controller
public class PatientController 
{
	@Autowired
	Patientrepo prepo;
	
	@Autowired
	Appoinmentrepo arepo;
	
	@Autowired
	Contactrepo crepo;
	
	@RequestMapping("/")
    public String home() 
	{
		
		return "main.jsp"; 
	}
	@RequestMapping("/signup")
	public String signup(@ModelAttribute Patient ob,@RequestParam String email)
	{
		Patient obj=prepo.findByEmail(email);
		if(obj!=null)
		{
			return "main.jsp?message='This Mail is Already Exist'";
		}
		else
		{
			prepo.save(ob);
			return "Userlogin.jsp?message='Registration Successful'";
		}
	}
		
	
	
	@RequestMapping("/login1")
	public String login(@RequestParam String email,@RequestParam String password)
	{
		Patient ob=prepo.findByEmail(email);
		System.out.println(ob);
		if(ob!=null && ob.getEmail().equalsIgnoreCase(email) && ob.getPassword().equals(password))
		{
			return "Bookappoinment.jsp";
		}
		else
		{
			return "main.jsp";
		}
	}

	@RequestMapping("/book")
	public String book_appoinment(@ModelAttribute Appoinment ob1)
	{
		arepo.save(ob1);
		return"redirect:/fetch";
	}
        
	@RequestMapping("/fetch")
	public String datafetch(Model data)
	{
		List<Appoinment> a1=arepo.findAll();
		System.out.println(a1);
		data.addAttribute("data", a1);
		return "Datafetch.jsp";
	}
	@RequestMapping("/Delete/{id}")
	public String delete(@PathVariable int id)
	{
		arepo.deleteById(id);
		return"redirect:/fetch";
	}
	@RequestMapping("{id}")
	public String update(@PathVariable int id,Model m)
	{
		Appoinment ob=arepo.findById(id).orElse(null);
		m.addAttribute("data", ob);
		
		return "edit.jsp";
	}
	
	@RequestMapping("/edit/{id}")
	public String update(@PathVariable int id,@ModelAttribute Appoinment ee)
	{
		Appoinment ob=arepo.findById(id).orElse(null);
	    if(ob!=null)
	    {
	    	ob.setAddress(ee.getAddress());
	    	ob.setMobile(ee.getMobile());
	    	ob.setName(ee.getName());
	    	ob.setDate(ee.getDate());
	    	ob.setTime(ee.getTime());
	    	arepo.save(ob);
	    	
	    }
	    return "redirect:/fetch";
	}
	@RequestMapping("/Contact")
	public String contact(@ModelAttribute Contact ob)
	{
		crepo.save(ob);
		return "Success.jsp";
	}
	
	@RequestMapping("/Search")
	public String name(@RequestParam String name,Model m)
	{
		List<Appoinment> a1=arepo.findByName(name);
		System.out.println(a1);
	    if(!a1.isEmpty())
	    {
			m.addAttribute("asmi", a1);
			return "Search.jsp";
	    }
	    else
	    {
	    	return "fail.jsp";
	    }
	}
}
