package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.model.Appoinment;
import com.project.model.Doctor;
import com.project.model.Patient;
import com.project.repository.Appoinmentrepo;
import com.project.repository.Doctorrepo;

@Controller
public class Doctorcontroller 
{
	@Autowired
	Doctorrepo drepo;
	
	@Autowired
	Appoinmentrepo arepo;
	
	@RequestMapping("/adminsignup")
    public String register(@ModelAttribute Doctor ob,@RequestParam int id) 
	{
		Doctor obj=drepo.findById(id);
		if(obj!=null)
		{
			return "main.jsp?message='This id is Already Exist'";
		}
		else
		{
			drepo.save(ob);
			return "Doctorlogin.jsp?message='Registration Successful'";
		} 
	}
	@RequestMapping("/login")
	public String login()
	{
			return "Doctorlogin.jsp";
	}
	@RequestMapping("/Appoinment")
	public String Appoinment(@RequestParam int id,@RequestParam String password)
	{
		Doctor ob=drepo.findById(id);
		System.out.println(ob);
		if(ob!=null && ob.getId()==id && ob.getPassword().equals(password))
		{
			return "redirect:/schudule";
		}
		else
		{
			return "Doctorregister.jsp";
		}
	}
	@RequestMapping("/schudule")
	public String Schudule(Model data)
	{
		List<Doctor> a1=drepo.findAll();
		System.out.println(a1);
		data.addAttribute("data", a1);
		return "Doctordatafetch.jsp";
	}
	@RequestMapping("/seeappoinment")
	public String Appoinment(Model data)
	{
		List<Appoinment> a1=arepo.findAll();
		System.out.println(a1);
		data.addAttribute("data", a1);
		return "Appoinments.jsp";
	}
}
